const express = require("express");
const session = require("express-session");
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");
const path = require("path");
const bodyParser = require("body-parser");
const fs = require("fs"); // ✅ Import fs

const app = express();
const PORT = 5000;

app.use(bodyParser.urlencoded({ extended: true }));

// ✅ Setup MySQL Database Connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "StudentDB",
});

db.connect(err => {
  if (err) {
    console.error("❌ MySQL Connection Failed:", err.message);
    process.exit(1);
  }
  console.log("✅ Connected to MySQL Database");
});

// ✅ Session setup
app.use(
  session({
    secret: "mySecretKey",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }, // Change to true in production
  })
);

// ✅ Serve static files
app.use(express.static(path.join(__dirname, "admin"), { index: false }));

// ✅ Home Route (Attendance Data)
app.get("/", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login.html");
  }

  const sqlAttendance = "SELECT * FROM attendance";
  const sqlSchedule = "SELECT * FROM schedule";

  // Execute both queries in parallel
  db.query(sqlAttendance, (err, attendanceResults) => {
    if (err) {
      console.error("❌ Error fetching attendance:", err);
      return res.send("❌ Error fetching attendance data.");
    }

    db.query(sqlSchedule, (err, scheduleResults) => {
      if (err) {
        console.error("❌ Error fetching schedule:", err);
        return res.send("❌ Error fetching schedule data.");
      }

      // Read the HTML file only once
      fs.readFile(path.join(__dirname, "admin", "index.html"), "utf8", (err, data) => {
        if (err) {
          return res.send("❌ Error loading HTML file.");
        }

        // Replace placeholders for attendance
        let attendancesHtml = attendanceResults
          .map(
            (item, index) => `
              <div class="row thead">
                <div class="row">${index + 1}</div>
                <div class="row">${item.module}</div>
                <div class="row">${item.module_code}</div>
                <div class="row">${item.student_id}</div>
                <div class="row">${item.lecture_code}</div>
                <div class="row"><div class="approved">Approved</div></div>
              </div>`
          )
          .join("");

        data = data.replace('<div id="attendance-placeholder"></div>', attendancesHtml);

        // Replace placeholders for schedule
        let scheduleHtml = scheduleResults
          .map(
            (item, index) => `
              <div class="row thead">
                <div class="row">${index + 1}</div>
                <div class="row">${item.module}</div>
                <div class="row">${item.module_code}</div>
                <div class="row">${item.lecturer}</div>
                <div class="row">${item.time_set}</div>
                <div class="row">${item.schedule_day}</div>
              </div>`
          )
          .join("");

        data = data.replace('<div id="schedule-placeholder"></div>', scheduleHtml);

        // ✅ Send final response only ONCE
        res.send(data);
      });
    });
  });
});


// ✅ Register User
app.post("/register", async (req, res) => {
  const { fName, email, phone, userName, pwd } = req.body;

  if (!fName || !email || !phone || !userName || !pwd) {
    return res.send("❌ All fields are required.");
  }

  try {
    const hashedPwd = await bcrypt.hash(pwd, 10);
    const sql = "INSERT INTO admin_panel (f_name, email, phone, user_name, pwd) VALUES (?, ?, ?, ?, ?)";
    db.query(sql, [fName, email, phone, userName, hashedPwd], (err, result) => {
      if (err) {
        console.error("❌ Registration error:", err);
        return res.send("❌ Error: Could not register.");
      }
      res.send("✅ Signup successful! <a href='/login.html'>Login here</a>");
    });
  } catch (error) {
    console.error("❌ Hashing error:", error);
    res.send("❌ Server error. Please try again.");
  }
});

// ✅ Login User
app.post("/login", (req, res) => {
  const { userName, pwd } = req.body;

  if (!userName || !pwd) {
    return res.send("❌ All fields are required.");
  }

  const sql = "SELECT * FROM admin_panel WHERE user_name = ?";
  db.query(sql, [userName], async (err, results) => {
    if (err) {
      console.error("❌ Database error:", err);
      return res.send("❌ Server error. Please try again later.");
    }

    if (results.length === 0) {
      return res.send("❌ Invalid username. <a href='/login.html'>Try again</a>");
    }

    const user = results[0];

    try {
      const isMatch = await bcrypt.compare(pwd, user.pwd);
      if (!isMatch) {
        return res.send("❌ Incorrect password. <a href='/login.html'>Try again</a>");
      }

      req.session.user = user.id;
      res.redirect("/");
    } catch (error) {
      console.error("❌ Password comparison error:", error);
      res.send("❌ Error during login. Please try again.");
    }
  });
});

app.post("/newGrade", async (req, res) => {
  const { module, moduleCode, grade } = req.body;

  try {
    const sql = "INSERT INTO grade (module, code, grade) VALUES (?, ?, ?)";
    db.query(sql, [module, moduleCode, grade], (err, result) => {
      if (err) {
        console.error("Entry Failed:", err);
        return res.send("Error recording entry");
      }
      res.send("✅ Entry was Successful");
    });
  } catch (error) {
    console.error("Failed:", error);
    res.send("Server error. Please try Again.");
  }
});

app.post("/newModule", async (req, res) => {
  const { module, moduleCode} = req.body;

  try {
    const sql = "INSERT INTO module (module, code) VALUES (?, ?)";
    db.query(sql, [module, moduleCode], (err, result) => {
      if (err) {
        console.error("Entry Failed:", err);
        return res.send("Error recording entry");
      }
      res.send("✅ Entry was Successful");
    });
  } catch (error) {
    console.error("Failed:", error);
    res.send("Server error. Please try Again.");
  }
});


// ✅ Logout User
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login.html");
  });
});

// ✅ Start Server
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
