const navBtn1 = document.querySelector(".navBtn1");
const navBtn2 = document.querySelector(".navBtn2");
const navBtn3 = document.querySelector(".navBtn3");
const navBtn4 = document.querySelector(".navBtn4");
const navBtn5 = document.querySelector(".navBtn5");

let displayBox = document.querySelector(".newC");
let displayBox1 = document.querySelector(".newC1");
let displayBox2 = document.querySelector(".newC2");
let displayBox3 = document.querySelector(".newC3");
let displayBox4 = document.querySelector(".newC4");
let displayBox5 = document.querySelector(".newC5");

navBtn1.addEventListener("click", () => {
    displayBox.classList.add("none");
    displayBox1.classList.remove("none");
    displayBox2.classList.add("none");
    displayBox3.classList.add("none");
    displayBox4.classList.add("none");
    displayBox5.classList.add("none");
});

navBtn2.addEventListener("click", () => {
    displayBox.classList.add("none");
    displayBox1.classList.add("none");
    displayBox2.classList.remove("none");
    displayBox3.classList.add("none");
    displayBox4.classList.add("none");
    displayBox5.classList.add("none");
});

navBtn3.addEventListener("click", () => {
    displayBox.classList.add("none");
    displayBox1.classList.add("none");
    displayBox2.classList.add("none");
    displayBox3.classList.remove("none");
    displayBox4.classList.add("none");
    displayBox5.classList.add("none");
});

navBtn4.addEventListener("click", () => {
    displayBox.classList.add("none");
    displayBox1.classList.add("none");
    displayBox2.classList.add("none");
    displayBox3.classList.add("none");
    displayBox4.classList.remove("none");
    displayBox5.classList.add("none");
});

navBtn5.addEventListener("click", () => {
    displayBox.classList.add("none");
    displayBox1.classList.add("none");
    displayBox2.classList.add("none");
    displayBox3.classList.add("none");
    displayBox4.classList.add("none");
    displayBox5.classList.remove("none");
});