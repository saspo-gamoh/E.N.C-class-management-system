let navBar1 = document.querySelector(".navBtn1");
let navBar2 = document.querySelector(".navBtn2");
let navBar3 = document.querySelector(".navBtn3");
let navBar4 = document.querySelector(".navBtn4");
let navBar5 = document.querySelector(".navBtn5");
let navBar7 = document.querySelector(".navBtn7");
let displayBox = document.querySelector(".newC");
let displayBox1 = document.querySelector(".newC1");
let displayBox2 = document.querySelector(".newC2");
let displayBox3 = document.querySelector(".newC3");
let displayBox4 = document.querySelector(".newC4");
let displayBox5 = document.querySelector(".newC5");
let displayBox7 = document.querySelector(".newC7");
navBar1.onclick = () =>{
    displayBox.classList.add("none");
    displayBox1.classList.remove("none");
    displayBox2.classList.add("none");
    displayBox3.classList.add("none");
    displayBox4.classList.add("none");
    displayBox5.classList.add("none");
}
navBar2.onclick = () =>{
    displayBox.classList.add("none");
    displayBox1.classList.add("none");
    displayBox2.classList.remove("none");
    displayBox3.classList.add("none");
    displayBox4.classList.add("none");
    displayBox5.classList.add("none");
}
navBar3.onclick = () =>{
    displayBox.classList.add("none");
    displayBox1.classList.add("none");
    displayBox2.classList.add("none");
    displayBox3.classList.remove("none");
    displayBox4.classList.add("none");
    displayBox5.classList.add("none");
}
navBar4.onclick = () =>{
    displayBox.classList.add("none");
    displayBox1.classList.add("none");
    displayBox2.classList.add("none");
    displayBox3.classList.add("none");
    displayBox4.classList.remove("none");
    displayBox5.classList.add("none");
}
navBar5.onclick = () =>{
    displayBox.classList.add("none");
    displayBox1.classList.add("none");
    displayBox2.classList.add("none");
    displayBox3.classList.add("none");
    displayBox4.classList.add("none");
    displayBox5.classList.remove("none");
}
navBar7.onclick = () =>{
    displayBox.classList.add("none");
    displayBox1.classList.add("none");
    displayBox2.classList.add("none");
    displayBox3.classList.add("none");
    displayBox4.classList.add("none");
    displayBox5.classList.add("none");
    displayBox7.classList.remove("none");
}
