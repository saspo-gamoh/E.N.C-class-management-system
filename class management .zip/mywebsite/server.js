const express = require("express");
const session = require("express-session");
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");
const path = require("path");
const bodyParser = require("body-parser");
const fs = require('fs');  // Required for reading and modifying the HTML file

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));

// ✅ Setup MySQL Database Connection
const db = mysql.createConnection({
  host: "localhost",     // Change this if your MySQL host is different
  user: "root",          // Use your MySQL username
  password: "",          // Use your MySQL password (leave empty if no password)
  database: "studentDB", // Ensure this matches your actual database name
});

// 🔍 Check if Database is Connected
db.connect(err => {
  if (err) {
    console.error("❌ MySQL Connection Failed:", err.message);
    process.exit(1); // Stop server if DB is not connected
  }
  console.log("✅ Connected to MySQL Database");
});

// Session setup
app.use(
  session({
    secret: "mySecretKey",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false },
  })
);

// Serving static files (like images, CSS, etc.)
app.use(express.static(path.join(__dirname, "public"), { index: false }));

// Home Route: Check if the user is logged in and fetch schedules from DB
// app.get("/", (req, res) => {
//   if (!req.session.user) {
//     return res.redirect("/login.html"); // Redirect if not logged in
//   }

//   // Fetch schedules from the database
//   const sql = "SELECT * FROM schedule";
//   const sqlGrade = "SELECT * FROM grade";
//   const sqlModule = "SELECT * FROM module";
//   db.query(sql, (err, results) => {
//     if (err) {
//       console.error("❌ Error fetching schedules:", err);
//       return res.send("❌ Error fetching schedules.");
//     }

//     // Read the index.html file and inject the schedules data
//     fs.readFile(path.join(__dirname, "public", "index.html"), 'utf8', (err, data) => {
//       if (err) {
//         return res.send("Error loading HTML file.");
//       }

//       // Inject schedules data into the HTML
//       let schedulesHtml = '';
//       results.forEach((schedule, index) => {
//         schedulesHtml += `
//           <div class="row thead">
//             <div class="row">${index + 1}</div>
//             <div class="row">${schedule.module}</div>
//             <div class="row">${schedule.lecturer}</div>
//             <div class="row">${schedule.time_set}</div>
//             <div class="row">${schedule.schedule_day}</div>
//             <div class="row"><div class="approved">approved</div></div>
//           </div>
//         `;
//       });

//       // Replace placeholder in the HTML with the actual data
//       data = data.replace('<div id="schedules-placeholder"></div>', schedulesHtml);

//       // Send the updated HTML to the client
//       res.send(data);
//     });
//   });
// });

app.get("/", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login.html"); // Redirect if not logged in
  }

  // Define the SQL queries
  const sqlSchedule = "SELECT * FROM schedule";
  const sqlGrade = "SELECT * FROM grade";
  const sqlModule = "SELECT * FROM module";

  // Execute all three queries in parallel
  db.query(sqlSchedule, (err, scheduleResults) => {
    if (err) {
      console.error("❌ Error fetching schedules:", err);
      return res.send("❌ Error fetching schedules.");
    }

    db.query(sqlGrade, (err, gradeResults) => {
      if (err) {
        console.error("❌ Error fetching grades:", err);
        return res.send("❌ Error fetching grades.");
      }

      db.query(sqlModule, (err, moduleResults) => {
        if (err) {
          console.error("❌ Error fetching modules:", err);
          return res.send("❌ Error fetching modules.");
        }

        // Read the index.html file and inject data
        fs.readFile(path.join(__dirname, "public", "index.html"), 'utf8', (err, data) => {
          if (err) {
            return res.send("❌ Error loading HTML file.");
          }

          // Inject schedule data
          let schedulesHtml = '';
          scheduleResults.forEach((schedule, index) => {
            schedulesHtml += `
              <div class="row thead">
                <div class="row">${index + 1}</div>
                <div class="row">${schedule.module}</div>
                <div class="row">${schedule.lecturer}</div>
                <div class="row">${schedule.time_set}</div>
                <div class="row">${schedule.schedule_day}</div>
                <div class="row"><div class="approved">approved</div></div>
              </div>
            `;
          });
          data = data.replace('<div id="schedules-placeholder"></div>', schedulesHtml);

          // Inject grade data
          let gradesHtml = '';
          gradeResults.forEach((grade, index) => {
            gradesHtml += `
              <div class="row thead grade">
                <div class="row">${index + 1}</div>
                <div class="row">${grade.module}</div>
                <div class="row">${grade.code}</div>
                <div class="row">${grade.grade}</div>
                <div class="row"><div class="approved">approved</div></div>
              </div>
            `;
          });
          data = data.replace('<div id="grades-placeholder"></div>', gradesHtml);

          // Inject module data
          let modulesHtml = '';
          moduleResults.forEach((module, index) => {
            modulesHtml += `
              <div class="row thead grade">
                <div class="row">${index + 1}</div>
                <div class="row">${module.module}</div>
                <div class="row">${module.code}</div>
                <div class="row"><div class="pending">admin</div></div>
                <div class="row"><div class="approved">approved</div></div>
              </div>
            `;
          });
          data = data.replace('<div id="modules-placeholder"></div>', modulesHtml);

          // Send the updated HTML to the client
          res.send(data);
        });
      });
    });
  });
});

// Signup Route (For handling registration)
app.post("/signup", async (req, res) => {
  const { studentName, idNum, dept, year, pwd } = req.body;
  const hashedPwd = await bcrypt.hash(pwd, 10);

  const sql = "INSERT INTO students (student_name, student_id, department, year, password) VALUES (?, ?, ?, ?, ?)";
  db.query(sql, [studentName, idNum, dept, year, hashedPwd], (err, result) => {
    if (err) {
      return res.send("Error: Could not register student. <a href='/signup.html'>Try again</a>");
    }
    res.send("✅ Signup successful! <a href='/login.html'>Login here</a>");
  });
});

// Login Route (For handling login)
app.post("/login", (req, res) => {
  const { idNum, password } = req.body;

  const sql = "SELECT * FROM students WHERE student_id = ?";
  db.query(sql, [idNum], async (err, results) => {
    if (err || results.length === 0) {
      return res.send("❌ Invalid login. <a href='/login.html'>Try again</a>");
    }

    const user = results[0];
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.send("❌ Incorrect password. <a href='/login.html'>Try again</a>");
    }

    req.session.user = user.student_id; // Store the user ID in the session
    res.redirect("/"); // Redirect to homepage (dashboard)
  });
});

// New attendance route (to handle adding a new schedule)
app.post("/attendance", (req, res) => {
  const { module, moduleCode, idNum, lectureCode } = req.body;

  // Ensure all fields are provided
  if (!module || !moduleCode || !idNum || !lectureCode) {
    return res.send("❌ All fields are required. Please fill out the form.");
  }

  // SQL query to insert the schedule into the database
  const sql = "INSERT INTO attendance (module, module_code, student_id, lecture_code) VALUES (?, ?, ?, ?)";
  db.query(sql, [module, moduleCode, idNum, lectureCode], (err, result) => {
    if (err) {
      console.error("❌ Error saving attendance:", err); // Log the error
      return res.send("❌ Error saving attendance. Please try again.");
    }

    // Respond with a success message
    res.send("✅ Attendance posted successfully! <a href='/'>Go Back</a>");
  });
});

// New schedule route (to handle adding a new schedule)
app.post("/addSchedule", (req, res) => {
  const { module, moduleCode, lecturer, TimeSet, dateSet } = req.body;

  //Ensure all fields are provided
  if (!module || !moduleCode || !lecturer || !TimeSet || !dateSet){
    return res.send("❌ All fields are required. Please fill out the form.");
  }

  //SQL query to insert the schedule into the database
  const sql = "INSERT INTO schedule (module, module_code, lecturer, time_set, schedule_day) VALUES (?, ?, ?, ?, ?)";
  db.query(sql, [module, moduleCode, lecturer, TimeSet, dateSet], (err, result) => {
    if (err) {
      console.error("❌ Error saving schedule:", err); // Log the error
      return res.send("❌ Error saving Schedule. Please try again.");
    }

    //Respond with a success message
    res.send("✅ Schedule posted successfully!  <a href='/'>Go Back</a>");
  });
});

// Logout Route (For handling logout)
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login.html"); // Redirect to login after logout
  });
});

// Start Server
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
