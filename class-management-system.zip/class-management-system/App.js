import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AuthProvider, useAuth } from './screens/AuthContext';
import Login from './screens/login';
import Signup from './screens/signup';
import App from './screens/dashboard';
import Grades from './screens/grades';
import Students from './screens/students';
import NewStudent from './screens/newStudent'; 
import NewGrade from './screens/NewGrade';
import Schedule from './screens/schedule';
import NewSchedule from './screens/newSchedule';
import Attendance from './screens/attendance';
import NewAttendance from './screens/newattendance';

const Stack = createNativeStackNavigator();

const Root = () => {
    return (
        <AuthProvider>
            <NavigationContainer>
                <MainNavigator />
            </NavigationContainer>
        </AuthProvider>
    );
};

const MainNavigator = () => {
    const { isAuthenticated } = useAuth();

    return (
        <Stack.Navigator initialRouteName="Login">
            {isAuthenticated ? (
                <>
                    <Stack.Screen 
                        name="App" 
                        component={App} 
                        options={{ headerShown: false }} 
                    />
                    <Stack.Screen
                        name="NewStudent" 
                        component={NewStudent} 
                        options={{ headerShown: true }} 
                    />
                    <Stack.Screen
                        name="NewSchedule" 
                        component={NewSchedule} 
                        options={{ headerShown: true }} 
                    />
                    <Stack.Screen
                        name="NewAttendance" 
                        component={NewAttendance} 
                        options={{ headerShown: true }} 
                    />
                    <Stack.Screen
                        name="Students" 
                        component={Students} 
                        options={{ headerShown: false }} 
                    />
                    <Stack.Screen 
                        name="Grades" 
                        component={Grades}  
                        options={{ headerShown: false }} 
                    />
                    <Stack.Screen 
                        name="Attendance" 
                        component={Attendance}  
                        options={{ headerShown: false }} 
                    />
                    <Stack.Screen
                      name="NewGrade"
                      component={NewGrade}
                      options={{ headerShown: true }}
                    />
                    <Stack.Screen
                      name="Schedule"
                      component={Schedule}
                      options={{ headerShown: false}}
                    />
                </>
            ) : (
                <>
                    <Stack.Screen 
                        name="Login" 
                        component={Login} 
                        options={{ headerShown: false }} 
                    />
                    <Stack.Screen 
                        name="Signup" 
                        component={Signup} 
                        options={{ headerShown: false }} 
                    />
                </>
            )}
        </Stack.Navigator>
    );
};

export default Root;