import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import styles from "../styles/styles"; // Import styles
import { useAuth } from './AuthContext'; // Import Auth context

const NewGrade = ({ navigation }) => {
  const [studentName, setStudentName] = useState("");
  const [grade, setGrade] = useState("");
  const [module, setModule] = useState("");
  const [idNum, setIdNum] = useState("");

  const { login } = useAuth(); // Ensure you get the login function from context

  const handleSaveData = async () => {
    try {
      const response = await fetch('http://cmgt.atwebpages.com/grade.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `studentName=${encodeURIComponent(studentName)}&grade=${encodeURIComponent(grade)}&module=${encodeURIComponent(module)}&idNum=${encodeURIComponent(idNum)}`,
      });


      const data = await response.json();

      Alert.alert(data.message);

      
    } catch (error) {
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>New Grade Entry</Text>
      <TextInput
        style={styles.input}
        placeholder="Students Name"
        value={studentName}
        onChangeText={setStudentName}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Grade Earned"
        value={grade}
        onChangeText={setGrade}
        placeholderTextColor="#888"
        keyboardType="numeric"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Module"
        value={module}
        onChangeText={setModule}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Id Number"
        value={idNum}
        onChangeText={setIdNum}
        placeholderTextColor="#888"
        keyboardType="numeric"
        autoCapitalize="none"
      />
      <TouchableOpacity style={styles.button} onPress={handleSaveData}>
        <Text style={styles.buttonText}>Save Data</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NewGrade; // Ensure NewAsset is exported