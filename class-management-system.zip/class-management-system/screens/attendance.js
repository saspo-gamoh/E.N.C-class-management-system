import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, SafeAreaView, Platform, Dimensions, StatusBar, TouchableOpacity } from 'react-native';
import { PieChart } from 'react-native-chart-kit'; 
import styles from '../styles/dbStyles';
import Icon from 'react-native-vector-icons/FontAwesome'; 
import globalStyle from '../styles/dbStyles';
import Footer from './footer';

const Attendance = ({ navigation }) => {
  const [totalAttendance, setTotalAttendance] = useState(0);
  const [attend, setAttend] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try{
       const attendanceResponde = await fetch('http://cmgt.atwebpages.com/fetch_attendance.php');
        const attendanceResult = await attendanceResponde.json();
        setTotalAttendance(attendanceResult.total);
        const attendanceResponse = await fetch('http://cmgt.atwebpages.com/total_attendance.php');
        const attendanceData = await attendanceResponse.json();

        const colors = ['#ffce56', '#4bc0c0']; // Define color palette
        const formattedTrends = [
          { name: "Morning", population: parseInt(attendanceData.early, 10), color: colors[0] },
          { name: "Afternoon", population: parseInt(attendanceData.noon, 10), color: colors[1] }
        ];

        setAttend(formattedTrends);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView contentContainerStyle={Platform.OS === 'android' ? styles.andriodStyle : {}} style={globalStyle.paddingScrollView}>
        <View style={globalStyle.displayCol}> 
          <Text style={globalStyle.title}>Attendance</Text>
          <TouchableOpacity style={globalStyle.plusBtn} onPress={() => navigation.navigate('NewAttendance')}>
            <Icon name="plus" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
        <View style={globalStyle.textTitleView}>
          <Text style={globalStyle.textTitle}>Attendance</Text>
          <View style={globalStyle.overView}>
            <Text style={globalStyle.textTitleSmall}>Total Attendance</Text>
            <Text style={globalStyle.currency}>{totalAttendance}</Text>
          </View>
          <Text style={globalStyle.textTitleSmall}>Attendance per Category</Text>
          <PieChart
            data={attend}
            width={Platform.OS === 'android' ? Dimensions.get('window').width - 20 : Dimensions.get('window').width}
            height={220}
            chartConfig={{
              backgroundColor: '#fff',
              backgroundGradientFrom: '#f6f6f6',
              backgroundGradientTo: '#f6f6f6',
              color: (opacity = 1) => `rgba(0, 122, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="#fff"
            paddingLeft="15"
            paddingRight="15"
            style={globalStyle.chart}
          />
        </View>
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Category</Text>
            <Text style={globalStyle.textTitleSmall}>Total</Text>
          </View>
          {attend.map((item, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{item.name}</Text>
              <Text style={globalStyle.displayText}>{item.population}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
      <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default Attendance;