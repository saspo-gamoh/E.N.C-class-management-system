import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, SafeAreaView, Platform, Dimensions, StatusBar, Alert } from 'react-native';
import { PieChart } from 'react-native-chart-kit'; 
import globalStyle from '../styles/dbStyles';
import Footer from './footer';

const App = ({ navigation }) => {
  const [totalAttendance, setTotalAttendance] = useState(0);
  const [totalSchedule, setTotalSchedule] = useState(0);
  const [totalStudents, setTotalStudents] = useState(0);
  const [grade, setGrade] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try{
      const attendanceResponde = await fetch('http://cmgt.atwebpages.com/fetch_attendance.php');
      const attendanceResult = await attendanceResponde.json();
      setTotalAttendance(attendanceResult.total);
      const scheduleResponse = await fetch('http://cmgt.atwebpages.com/fetch_schedule.php');
      const scheduleResult = await scheduleResponse.json(); 
      setTotalSchedule(scheduleResult.total);
      const studentResponse = await fetch('http://cmgt.atwebpages.com/fetch_student.php');
      const studentResult = await studentResponse.json();
      setTotalStudents(studentResult.total);
      const gradeResponse = await fetch('http://cmgt.atwebpages.com/fetch_grade.php');
      const gradeResult = await gradeResponse.json();

      const colors = ['#ffce56', '#4bc0c0']; // Define color palette
      const formattedTrends = [
        { name: "Pass", population: parseInt(gradeResult.pass, 10), color: colors[0] },
        { name: "Fail", population: parseInt(gradeResult.fail, 10), color: colors[1] }
      ];

      setGrade(formattedTrends);

    } catch (error) {
      Alert.alert("An unexpected error occured!");
    }
  };

  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView contentContainerStyle={Platform.OS === 'android' ? globalStyle.andriodStyle : {}} style={globalStyle.paddingScrollView}>
        <View style={globalStyle.displayCol}> 
          <Text style={globalStyle.title}>Dashboard</Text>
        </View>
        <View style={globalStyle.textTitleView}>
          <Text style={globalStyle.textTitle}>Overview</Text>
          <View style={globalStyle.overView}> 
            <Text style={globalStyle.textTitleSmall}>Total Attendace</Text>
            <Text style={globalStyle.currency}>{totalAttendance}</Text>
          </View>
          <Text style={globalStyle.textTitleSmall}>Grade's Rating</Text>
          <PieChart 
            data={grade}
            width={Platform.OS === 'android' ? Dimensions.get('window').width - 20 : Dimensions.get('window').width}
            height={220}
            chartConfig={{
              backgroundColor: '#fff',
              backgroundGradientFrom: '#f6f6f6',
              backgroundGradientTo: '#f6f6f6',
              color: (opacity = 1) => `rgba(0, 122, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="#fff"
            paddingLeft="15"
            paddingRight="15"
            style={globalStyle.chart}
          />
        </View>
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Schedule</Text>
            <Text style={globalStyle.textTitleSmall}>Total</Text>
          </View>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.displayText}>Total</Text>
            <Text style={globalStyle.displayText}>{totalSchedule}</Text>
          </View>
        </View>
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}> 
            <Text style={globalStyle.textTitleSmall}>Students</Text>
            <Text style={globalStyle.textTitleSmall}>Totals</Text>
          </View>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.displayText}>Total</Text>
            <Text style={globalStyle.displayText}>{totalStudents}</Text>
          </View>
        </View>
      </ScrollView>
      <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default App;