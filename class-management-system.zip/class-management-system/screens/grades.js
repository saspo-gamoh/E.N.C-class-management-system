import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, SafeAreaView, Platform, Dimensions, StatusBar, TouchableOpacity } from 'react-native';
import { PieChart } from 'react-native-chart-kit'; 
import styles from '../styles/dbStyles';
import Icon from 'react-native-vector-icons/FontAwesome'; 
import globalStyle from '../styles/dbStyles';
import Footer from './footer';

const Grades = ({ navigation }) => {
  const [totalGrade, setTotalGrade] = useState(0);
  const [grade, setGrade] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const gradeResponse = await fetch('http://cmgt.atwebpages.com/total_grade.php');
    const gradeResult = await gradeResponse.json();
    setTotalGrade(gradeResult.total);
    const gradeFetch = await fetch('http://cmgt.atwebpages.com/fetch_grade.php');
    const gradeFetched = await gradeFetch.json();

    const colors = ['#ffce56', '#4bc0c0']; // Define color palette
    const formattedTrends = [
      { name: "Pass", population: parseInt(gradeFetched.pass, 10), color: colors[0] },
      { name: "Fail", population: parseInt(gradeFetched.fail, 10), color: colors[1] }
    ];

    setGrade(formattedTrends);
  };

  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView contentContainerStyle={Platform.OS === 'android' ? styles.andriodStyle : {}} style={globalStyle.paddingScrollView}>
        <View style={globalStyle.displayCol}> 
          <Text style={globalStyle.title}>Grades</Text>
          <TouchableOpacity style={globalStyle.plusBtn} onPress={() => navigation.navigate('NewGrade')}>
            <Icon name="plus" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
        <View style={globalStyle.textTitleView}> 
          <Text style={globalStyle.textTitle}>Grade</Text>
          <View style={globalStyle.overView}>
            <Text style={globalStyle.textTitleSmall}>Grade Scored</Text>
            <Text style={globalStyle.currency}>{totalGrade}</Text>
          </View>
          <Text style={globalStyle.textTitleSmall}>Grade per Category</Text>
          <PieChart
            data={grade}
            width={Platform.OS === 'android' ? Dimensions.get('window').width - 20 : Dimensions.get('window').width}
            height={220}
            chartConfig={{
              backgroundColor: '#fff',
              backgroundGradientFrom: '#f6f6f6',
              backgroundGradientTo: '#f6f6f6',
              color: (opacity = 1) => `rgba(0, 122, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="#fff"
            paddingLeft="15"
            paddingRight="15"
            style={globalStyle.chart}
          />
        </View>
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Category</Text>
            <Text style={globalStyle.textTitleSmall}>Total</Text>
          </View>
          {grade.map((item, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{item.name}</Text>
              <Text style={globalStyle.displayText}>{item.population}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
      <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default Grades;