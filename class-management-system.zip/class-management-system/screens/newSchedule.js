import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import styles from "../styles/styles"; // Import styles
import { useAuth } from './AuthContext'; // Import Auth context

const NewSchedule = ({ navigation }) => {
  const [type, setType] = useState(""); // Renamed variable for clarity
  const [studentId, setStudentId] = useState(""); // Renamed variable for clarity
  const [module, setModule] = useState(""); // Renamed variable for clarity
  const [day, setDay] = useState(""); // Renamed variable for clarity

  const { login } = useAuth(); // Ensure you get the login function from context

  const handleSaveData = async () => {
    try {
      const response = await fetch('http://cmgt.atwebpages.com/schedule.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `type=${encodeURIComponent(type)}&studentId=${encodeURIComponent(studentId)}&module=${encodeURIComponent(module)}&day=${encodeURIComponent(day)}`,
      });

      

      const data = await response.json();

      Alert.alert(data.message);
    } catch (error) {
      Alert.alert("Inserting failed due to an invalid command!");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>New Schedule Entry</Text>
      <TextInput
        style={styles.input}
        placeholder="Regular or InRegular"
        value={type}
        onChangeText={setType}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Student Id"
        value={studentId}
        onChangeText={setStudentId}
        placeholderTextColor="#888"
        keyboardType="numeric" // Ensure numeric input for amount
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Module"
        value={module}
        onChangeText={setModule}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
       <TextInput
        style={styles.input}
        placeholder="Day of Lecture"
        value={day}
        onChangeText={setDay}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TouchableOpacity style={styles.button} onPress={handleSaveData}>
        <Text style={styles.buttonText}>Save Data</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NewSchedule;