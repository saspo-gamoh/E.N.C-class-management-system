import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import styles from "../styles/styles"; // Import styles
import { useAuth } from './AuthContext'; // Import Auth context

const NewStudent = ({ navigation }) => {
  const [username, setUsername] = useState("");
  const [gender, setGender] = useState("");
  const [idNum, setIdNum] = useState("");
  const [program, setProgram] = useState("");

  const { login } = useAuth(); // Ensure you get the login function from context

  const handleSaveData = async () => {
    try {
      const response = await fetch('http://cmgt.atwebpages.com/save.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `username=${encodeURIComponent(username)}&gender=${encodeURIComponent(gender)}&idNum=${encodeURIComponent(idNum)}&program=${encodeURIComponent(program)}`,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.message === "Data saved successfully") {
        // Uncomment to update auth state
        // login(); 
        // Uncomment to redirect to App screen
        // navigation.navigate('App'); 
        Alert.alert("Saved Successfully");
      } else {
        Alert.alert("Error", data.message || "Failed to save data.");
      }
    } catch (error) {
      console.error('Error:', error);
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>New Student Entry</Text>
      <TextInput
        style={styles.input}
        placeholder="Student Name"
        value={username}
        onChangeText={setUsername}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Gender (M/F)"
        value={gender}
        onChangeText={setGender}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Student I.D Number"
        value={idNum}
        onChangeText={setIdNum}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Student Program"
        value={program}
        onChangeText={setProgram}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TouchableOpacity style={styles.button} onPress={handleSaveData}>
        <Text style={styles.buttonText}>Save Data</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NewStudent; // Ensure NewStudent is exported