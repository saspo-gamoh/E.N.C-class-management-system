import React, {useState, useEffect} from 'react';
import { View, Text, ScrollView, SafeAreaView, Platform, Dimensions, StatusBar, TouchableOpacity, Alert } from 'react-native';
import { PieChart } from 'react-native-chart-kit'; 
import styles from '../styles/dbStyles';
import Icon from 'react-native-vector-icons/FontAwesome'; 
import globalStyle from '../styles/dbStyles';
import Footer from './footer';

const Schedule = ({ navigation }) => {
  const [totalSchedule, setTotalSchedule] = useState(0);
  const [totalSchedules, setTotalSchedules] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const scheduleResponse = await fetch('http://cmgt.atwebpages.com/fetch_schedule.php');
      const scheduleResult = await scheduleResponse.json(); 
      setTotalSchedule(scheduleResult.total);
      const schedulesResponse = await fetch('http://cmgt.atwebpages.com/total_schedule.php');
      const schedulesResult = await schedulesResponse.json();

      const colors = ['#ffce56', '#4bc0c0']; // Define color palette
      const formattedTrends = [
        { name: "Regular", population: parseInt(schedulesResult.regular, 10), color: colors[0] },
        { name: "Inregular", population: parseInt(schedulesResult.inregular, 10), color: colors[1] }
      ];

      setTotalSchedules(formattedTrends);

    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView contentContainerStyle={Platform.OS === 'android' ? styles.andriodStyle : {}} style={globalStyle.paddingScrollView}>
        <View style={globalStyle.displayCol}> 
          <Text style={globalStyle.title}>Schedule</Text>
          <TouchableOpacity style={globalStyle.plusBtn} onPress={() => navigation.navigate('NewSchedule')}>
            <Icon name="plus" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
        <View style={globalStyle.textTitleView}>
          <Text style={globalStyle.textTitle}>Schedule</Text>
          <View style={globalStyle.overView}>
            <Text style={globalStyle.textTitleSmall}>Total</Text>
            <Text style={globalStyle.currency}>{totalSchedule}</Text>
          </View>
          <Text style={globalStyle.textTitleSmall}>Schedule in Category</Text>
          <PieChart
            data={totalSchedules}
            width={Platform.OS === 'android' ? Dimensions.get('window').width - 20 : Dimensions.get('window').width}
            height={220}
            chartConfig={{
              backgroundColor: '#fff',
              backgroundGradientFrom: '#f6f6f6',
              backgroundGradientTo: '#f6f6f6',
              color: (opacity = 1) => `rgba(0, 122, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="#fff"
            paddingLeft="15"
            paddingRight="15"
            style={globalStyle.chart}
          />
        </View>
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>State</Text>
            <Text style={globalStyle.textTitleSmall}>Days</Text>
          </View>
          {totalSchedules.map((item, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{item.name}</Text>
              <Text style={globalStyle.displayText}>{item.population}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
       <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default Schedule;